import { Component } from '@angular/core';
import { Article } from './model/article';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Frigo';

  filter: 'all' | 'actif' | 'completed' = 'all';

  allArticles = [
    { id: 1, description: 'beurre', completed: true },
    { id: 2, description: 'mayonnaise', completed: false},
    { id: 3, description: 'céréales', completed: false},
    { id: 4, description: 'brocolis', completed: true},
    { id: 5, description: 'déodorant', completed: false}
  ];

  get articles() {
    if (this.filter === 'all'){
      return this.allArticles;
    }
    return this.allArticles.filter((article) => this.filter === 'completed' ? article.completed : !article.completed);
  }
  
  addArticle(id: number,description: string) {
    this.allArticles.unshift({
      id,
      description,
      completed: false
    });
  }

  remove(article: Article){
    this.allArticles.splice(this.allArticles.indexOf(article), 1);
  }







}
