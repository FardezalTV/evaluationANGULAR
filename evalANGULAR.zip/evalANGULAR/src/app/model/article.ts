export interface Article {
    id:number;
    description:string;
    completed:boolean;

}