import { Component } from '@angular/core';
import { Article } from '../model/article';
import { Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent {
  editable = false;

  @Input() article!: Article;
  @Input() newArticle!: string;
  @Output() remove = new EventEmitter<Article>();

  saveArticle(description: string) {
    if (!description) return;
    this.editable = false;
    this.article.description = description;

}
}
